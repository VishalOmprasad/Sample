﻿using System;
using Xamarin.Forms;

namespace SfMapsSample
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
        }

        private void LayerTypeButton_Clicked(object sender, EventArgs e)
        {
            if (this.TileLayer.LayerType == Syncfusion.SfMaps.XForms.LayerType.OSM)
            {
                this.TileLayer.LayerType = Syncfusion.SfMaps.XForms.LayerType.Bing;
            }
            else
            {
                this.TileLayer.LayerType = Syncfusion.SfMaps.XForms.LayerType.OSM;
            }
        }
    }
}
